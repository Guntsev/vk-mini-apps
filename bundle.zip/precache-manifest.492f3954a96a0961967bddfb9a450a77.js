self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9040df07bc229888e0a69a58da56bfca",
    "url": "/index.html"
  },
  {
    "revision": "17961684b71aab79bb22",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "fd9b2c3b84b3e4a70c6a",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "17961684b71aab79bb22",
    "url": "/static/js/2.baa97f53.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.baa97f53.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fd9b2c3b84b3e4a70c6a",
    "url": "/static/js/main.0df54324.chunk.js"
  },
  {
    "revision": "c36145c1033785165ef1",
    "url": "/static/js/runtime-main.f93b8094.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);